package tes.ai;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ArffLoader;
import weka.classifiers.bayes.NaiveBayes;
import weka.core.converters.ConverterUtils;
import weka.core.converters.ConverterUtils.DataSource;

import java.io.File;


public class Ai_test {

	public static void main(String[] args) throws Exception
	{

ConverterUtils.DataSource prediksi_ds,training_ds;

			NaiveBayes nb = new NaiveBayes();
		 training_ds = new ConverterUtils.DataSource("/Users/mac/Documents/project_AI/src/tes/ai/dataset.arff");
		Instances training_test = training_ds.getDataSet();
		
		if (training_test.classIndex() == -1)
			training_test.setClassIndex(training_test.numAttributes() - 1);

		 prediksi_ds = new ConverterUtils.DataSource("/Users/mac/Documents/project_AI/src/tes/ai/prediksi.arff");
		Instances prediksi_test = prediksi_ds.getDataSet();
		// setting class attribute if the data format does not provide this information
		// For example, the XRFF format saves the class attribute information as well
		if (prediksi_test.classIndex() == -1)
			prediksi_test.setClassIndex(training_test.numAttributes() - 1);

		// model 

		NaiveBayes naiveBayes = new NaiveBayes();
		naiveBayes.buildClassifier(training_test);

		// this does the trick
		double label = naiveBayes.classifyInstance(prediksi_test.instance(0));
		prediksi_test.instance(0).setClassValue(label);

                System.out.println("Dataset cuaca:  "+training_ds.getDataSet());
                System.out.println();
                                System.out.println();
                System.out.println();
           System.out.println("Soal:");
                 System.out.println(" jika cuaca=rainy,tempratur=60,humidity=70,windy=TRUE,play=?  ");
                                 System.out.println();
                System.out.println();

                                System.out.println("hasil prediksinya :  "+prediksi_test.instance(0).toString());


		System.out.println("hasil prediksinya :  "+prediksi_test.instance(0).stringValue(4));
	}


}
